"""
House Price Prediction pipeline script.

This script loads the Housing.csv file, cleans the data, trains Linear Regression
and Random Forest models, evaluates them, and saves model results.
"""

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score


def load_data(path="Housing.csv"):
    """Load the housing dataset from a CSV file."""
    return pd.read_csv(path)


def clean_data(df):
    """Remove duplicates, fill missing values and one-hot encode categorical columns."""
    df = df.drop_duplicates().copy()
    for col in df.columns:
        if df[col].dtype == "object":
            df[col] = df[col].fillna(df[col].mode()[0])
        else:
            df[col] = df[col].fillna(df[col].median())
    return pd.get_dummies(df, drop_first=True)


def evaluate_model(name, y_true, y_pred):
    """Return MAE, RMSE and R2 score for a model."""
    return {
        "Model": name,
        "MAE": mean_absolute_error(y_true, y_pred),
        "RMSE": np.sqrt(mean_squared_error(y_true, y_pred)),
        "R2 Score": r2_score(y_true, y_pred),
    }


def main():
    """Run the complete house price prediction pipeline."""
    df = load_data()
    encoded = clean_data(df)

    X = encoded.drop("price", axis=1)
    y = encoded["price"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    linear_model = LinearRegression()
    linear_model.fit(X_train, y_train)
    linear_pred = linear_model.predict(X_test)

    rf_model = RandomForestRegressor(n_estimators=250, random_state=42)
    rf_model.fit(X_train, y_train)
    rf_pred = rf_model.predict(X_test)

    results = pd.DataFrame([
        evaluate_model("Linear Regression", y_test, linear_pred),
        evaluate_model("Random Forest Regressor", y_test, rf_pred),
    ])

    results.to_csv("model_results.csv", index=False)
    print(results)


if __name__ == "__main__":
    main()
