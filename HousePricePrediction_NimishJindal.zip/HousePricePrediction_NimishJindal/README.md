# House Price Prediction - Internship Project Week 1

**Name:** Nimish Jindal  
**Project Title:** House Price Prediction  

## Project Overview
This project builds regression models to predict house prices using property features such as area, bedrooms, bathrooms, stories, amenities, parking, preferred area and furnishing status.

## Dataset
The project uses `Housing.csv` with columns:
- price
- area
- bedrooms
- bathrooms
- stories
- mainroad
- guestroom
- basement
- hotwaterheating
- airconditioning
- parking
- prefarea
- furnishingstatus

## Tasks Completed
1. Loaded and explored the dataset.
2. Checked rows, columns, target variable and missing values.
3. Cleaned the data and removed duplicates.
4. Converted categorical columns using one-hot encoding.
5. Built Linear Regression and Random Forest Regressor models.
6. Evaluated models using MAE, RMSE and R2 Score.
7. Created required charts.
8. Wrote insights and final summary.

## How to Run
Open Jupyter Notebook and run:

```bash
jupyter notebook analysis.ipynb
```

Or install dependencies first:

```bash
pip install -r requirements.txt
```

## Output Files
- `analysis.ipynb` - Complete notebook with all tasks
- `Housing.csv` - Dataset used
- `summary.pdf` - One-page summary
- `summary.docx` - Editable summary
- `charts/` - Saved charts
- `model_results.csv` - Model comparison
- `feature_importance.csv` - Important features
